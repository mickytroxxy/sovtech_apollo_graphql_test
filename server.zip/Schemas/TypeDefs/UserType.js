const graphql = require("graphql");
const { GraphQLObjectType, GraphQLInt, GraphQLString,GraphQLList } = graphql;

const UserType = new GraphQLObjectType({
  name: "User",
  fields: () => ({
    next: { type: GraphQLString },
    previous: { type: GraphQLString },
    count:{type:GraphQLInt},
    results: {
      type: new GraphQLList(userFields)
    },
  }),
});
const userFields = new GraphQLObjectType({
  name: 'userFields',
  fields: () => ({
    gender: { type: GraphQLString },
    name: { type: GraphQLString },
    height: { type: GraphQLString },
    mass: { type: GraphQLString },
    homeworld: { type: GraphQLString }
  })
})
module.exports = UserType;
