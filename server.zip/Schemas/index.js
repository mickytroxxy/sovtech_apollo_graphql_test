const graphql = require("graphql");
const fetch = require('node-fetch');
const {
  GraphQLObjectType,
  GraphQLSchema,
  GraphQLInt,
  GraphQLString,
  GraphQLList,
} = graphql;
const userData = require("../MOCK_DATA.json");

const UserType = require("./TypeDefs/UserType");
const BASE_URL = 'https://swapi.dev/api/people/?page=1';
const RootQuery = new GraphQLObjectType({
  name: "RootQueryType",
  fields: {
    getAllUsers: {
      type: new GraphQLList(UserType),
      args: { url: { type: GraphQLString } },
      resolve: (parent, args)=>{
        return fetch(args.url, { method: 'GET'}).then(res => res.json()).then(json => [json]);
      },
    },
  },
});

module.exports = new GraphQLSchema({ query: RootQuery, mutation: null });
