import "./App.css";
import Routes from './Components/Routes';
import { AppProvider } from './Components/context';

function App() {
  return (
    <AppProvider>
      <Routes></Routes>
    </AppProvider>
  );
}

export default App;
