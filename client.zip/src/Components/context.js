import React from 'react';
import {ApolloClient,InMemoryCache,ApolloProvider,HttpLink,from} from "@apollo/client";
import { onError } from "@apollo/client/link/error";
export const AppContext = React.createContext();

const errorLink = onError(({ graphqlErrors, networkError }) => {
    if (graphqlErrors) {
      graphqlErrors.map(({ message, location, path }) => {
        alert(`Graphql error ${message}`);
      });
    }
});
const link = from([
    errorLink,
    new HttpLink({ uri: "https://lameck-graphql.herokuapp.com/graphql" }),
]);
const apolloClient = new ApolloClient({
    cache: new InMemoryCache(),
    link: link,
});

export const AppProvider = (props) =>{
    const [users,setUsers]=React.useState([]);
    const [activeUser,setActiveUser]=React.useState(null);
    const [searchKey,setSearchKey]=React.useState(null);
    React.useEffect(()=>{
        
    },[])
    return(
        <ApolloProvider client={apolloClient}>
            <AppContext.Provider value={{users,setUsers,activeUser,setActiveUser,searchKey,setSearchKey}}>
                {props.children}
            </AppContext.Provider>
        </ApolloProvider>
    )
}