import React,{useState,useCallback} from 'react';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import Divider from '@material-ui/core/Divider';
import ListItemText from '@material-ui/core/ListItemText';
import ListItemAvatar from '@material-ui/core/ListItemAvatar';
import Avatar from '@material-ui/core/Avatar';
import { useQuery, gql } from "@apollo/client";
import { Button, Grid,Typography,makeStyles,Snackbar  } from '@material-ui/core';
import { LOAD_USERS } from "../GraphQL/Queries";
import { AppContext } from '../Components/context';
import history from './history';
const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%',
        backgroundColor: theme.palette.background.paper,
    },
    inline: {
        display: 'inline',
    },
    button: {
        marginTop:15,borderColor:'#3488a7',color:'#3488a7',outline:'none',
        '&:hover': {
            backgroundColor: '#3488a7',
            color: '#fff',
        }
    },
}));

export default function Body() {
    const classes = useStyles();
    const { users,setUsers,setActiveUser,searchKey} = React.useContext(AppContext);
    const [offset,setOffset]=React.useState(1);
    let BASE_URL = 'https://swapi.dev/api/people/?page='+offset;
    if(searchKey){
        BASE_URL = 'https://swapi.dev/api/people/?search='+searchKey
    };
    const { data } = useQuery(LOAD_USERS,{ variables: { url: BASE_URL }});
    React.useEffect(() => {
        getUsers();
    }, [data]);
    const goToProfile=user=>{
        setActiveUser(user);
        history.push('/Profile');
    }
    const handlePaginationClick=(action)=>{
        if(action==='prev'){
            users[0].previous!=null && setOffset(offset - 1);
        }else{
            users[0].next!=null && setOffset(offset + 1);
        }
    }
    const getUsers=()=>data&&setUsers(data.getAllUsers.slice(0,20));

    return (
        <List className={classes.root}>
            {users.length>0 && users[0]["results"].map((user,i) => {
                const {name,gender,mass,height}=user;
                return (
                    <div key={i}>
                        <ListItem alignItems="flex-start" style={{cursor:'pointer'}} onClick={() => goToProfile(user)}>
                            <ListItemAvatar>
                                <Avatar alt={name} src="https://picsum.photos/200" />
                            </ListItemAvatar>
                            <ListItemText
                                primary={name}
                                secondary={
                                <React.Fragment>
                                    <Typography
                                        component="span"
                                        variant="body2"
                                        color="textPrimary"
                                        >
                                       {"Is "+gender+", has a height of "+height+"m and weight of "+mass+"kg"}
                                    </Typography>
                                </React.Fragment>
                                }
                            />
                        </ListItem>
                        {/**<Divider variant="inset" component="li" /> */}
                    </div>
                );
            })}
            <Grid container style={{marginTop:50}}>
                <Grid item xs={12} sm={6}>
                    <center><Button onClick={()=>handlePaginationClick('prev')} style={{borderTopRightRadius:30,borderBottomLeftRadius:30}} className={classes.button} variant="outlined">PREVIOUS</Button></center>
                </Grid>
                <Grid item xs={12} sm={6}>
                    <center><Button onClick={()=>handlePaginationClick('next')} style={{borderTopRightRadius:30,borderBottomLeftRadius:30}} className={classes.button} variant="outlined">NEXT</Button></center>
                </Grid>
            </Grid>
        </List>
    );
}
