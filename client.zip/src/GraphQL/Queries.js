import { gql } from "@apollo/client";

export const LOAD_USERS = gql`
  query ($url: String!){
    getAllUsers(url: $url){
      next
      count
      previous
      results{
        gender
        name
        height
        mass
        homeworld
      }
    }
  }
`;
