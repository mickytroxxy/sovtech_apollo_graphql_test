import React,{useState} from "react";
import { Button, Grid,Container,makeStyles, TextField  } from '@material-ui/core';
import {SearchOutlined } from "@material-ui/icons";
import Fab from '@material-ui/core/Fab';
import { AppContext } from '../components/context';
import history from './history';
import Jokes from "./Images";
import '../App.css';
export default function Body() {
    const { setJokes,fetchApi} = React.useContext(AppContext);
    const [categories,setCategories]=useState([]);
    const classes = useStyles();
    const [searchKey,setSearchKey]=useState("");
    const { innerWidth,innerHeight } = window;
    const search_joke = async() =>{
        const {data} = await fetchApi({method:'GET',url:'https://api.chucknorris.io/jokes/search?query='+searchKey});
        setJokes(data.result)
    }
    React.useEffect(()=>{
        getCategories();
    },[]);
    const getCategories = React.useCallback(async()=>{
        const {data} = await fetchApi({method:'GET',url:'https://api.chucknorris.io/jokes/categories'});
        setCategories(data);
    },[]);
    const getByCategories = React.useCallback(async(category)=>{
        const {data} = await fetchApi({method:'GET',url:'https://api.chucknorris.io/jokes/random?category='+category});
        setJokes([data]);
    },[]);
    return (
        <Container maxWidth="xl" component="main" className={classes.heroContent} >
            <div className={classes.root}>
                <Grid container>
                    <Grid item xs={12} sm={6}>
                        <div style={{padding:50}}>
                            <center><h1 style={{fontFamily:"sans-serif",color:'#3f4750'}}>JUST FOR GIGS</h1></center>
                            <center><p style={{color:'#757575'}}>I started with react before facebook! You see you can trust me with jokes? Want to hear more? Type below!</p></center>
                            <TextField
                                id="outlined"
                                label="Search"
                                placeholder="Give me a hint..."
                                variant="outlined"
                                style={{width:'80%',[`& fieldset`]:{
                                    borderRadius:30
                                  }}}
                                onKeyUp={(e)=>setSearchKey(e.target.value)}
                                inputProps={{ maxLength: 20 }}
                            />
                            <center><Button onClick={search_joke} style={{borderTopRightRadius:30,borderBottomLeftRadius:30}} className={classes.button} variant="outlined">CLICK TO SEARCH</Button></center>
                        </div>
                        <div className={classes.root}>
                            {
                                categories.length > 0 && categories.map((item, i) =>(
                                    <div key={item} style={{margin:10,borderRadius:5,backgroundColor:'#edecec',padding:10}}>
                                        <a style={{outline:'none',color:'#2c2b2b'}} onClick={()=>{getByCategories(item)}}>{item}</a>           
                                    </div>
                                ))
                            }
                        </div>
                    </Grid>
                    <Grid item xs={12} sm={6}>
                        <Jokes />
                    </Grid>
                </Grid>
            </div>
            <Fab color="primary" onClick={()=>setSearchKey("")} aria-label="add" style={{position:'fixed',bottom:10,right:10}}>
                <SearchOutlined />
            </Fab>
        </Container>
    )
}




const useStyles = makeStyles((theme) => ({
    '@global': {
      ul: {
        margin: 0,
        padding: 0,
        listStyle: 'none',
      },
    },
    heroContent: {
      padding: theme.spacing(8, 0, 6),
    },
    paper: {
        padding: theme.spacing(2),
        textAlign: 'center',
        color: theme.palette.text.secondary,
    },
    root: {
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: 'space-around',
        overflow: 'hidden',
        cursor:'pointer',
    },
    gridList: {
        flexWrap: 'nowrap'
    },
    icon: {
        marginRight: theme.spacing(2),
    },
    heroButtons: {
        marginTop: theme.spacing(4),
    },
    cardGrid: {
        paddingTop: theme.spacing(8),
        paddingBottom: theme.spacing(8),
    },
    card: {
        display: 'flex',
        flexDirection: 'column',
    },
        cardMedia: {
        paddingTop: '56.25%', // 16:9
    },
        cardContent: {
        flexGrow: 1,
    },
    button: {
        marginTop:15,borderColor:'#3488a7',color:'#3488a7',outline:'none',
        '&:hover': {
          backgroundColor: '#3488a7',
          color: '#fff',
        }
    },
    footer: {
        backgroundColor: theme.palette.background.paper,
        padding: theme.spacing(6),
    },
}));