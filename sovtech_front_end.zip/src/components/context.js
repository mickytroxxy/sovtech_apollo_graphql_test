import React from 'react';
import axios from "axios";
export const AppContext = React.createContext();
export const AppProvider = (props) =>{
    const [jokes,setJokes]=React.useState([]);
    React.useEffect(()=>{},[])
    return(
        <AppContext.Provider value={{jokes,setJokes,fetchApi}}>
            {props.children}
        </AppContext.Provider>
    )
}
const fetchApi = searchOptions=>{ 
    try {
        return axios.request(searchOptions)
    } catch (error) {
        console.log(error);
        return;
    }
}