import React from "react";
import Carousel from 'react-material-ui-carousel'
import { Paper, Theme, createStyles, makeStyles, Button, CardMedia, CardContent, CardActions, CardActionArea, Card, GridListTile, GridList, Typography, Grid } from '@material-ui/core'
import { AppContext } from '../components/context';
import banner from '../img/banner.png';
import joker_found from '../img/joker_found.png';
const Jokes = () => {
    const { jokes} = React.useContext(AppContext);
    const classes = useStyles();
    React.useEffect(()=>{
        console.log(jokes)
    },[jokes])
    {/**<div className={classes.root}>
                    <GridList cellHeight={160} className={classes.gridList} cols={3}>
                        {jokes.map((image,i) => (
                            <GridListTile key={i} cols={1}>
                                <img src={image.image.src} alt={image.image.src} />
                            </GridListTile>
                        ))}
                    </GridList>
                </div> */}
    return (
        <div style={{alignItems:'center',alignContent:'center'}}>
            {jokes.length > 0 ?(
                <Grid
                    container
                    spacing={0}
                    direction="column"
                    alignItems="center"
                    justify="center"
                    style={{ minHeight: '100vh',marginTop:-100,width:'70%',marginLeft:'15%'}}
                >
                    <Grid item>
                        <Carousel>
                            {
                                jokes.map(({icon_url,updated_at,value})=>(
                                    <Card>
                                        <CardActionArea>
                                            <CardMedia
                                                component="img"
                                                alt="Lameck Ndhlovu"
                                                height="140"
                                                image={joker_found}
                                                title=""
                                            />
                                            <CardContent>
                                            <Typography gutterBottom variant="h5" component="h2">
                                                {updated_at}
                                            </Typography>
                                            <Typography variant="body2" color="textSecondary" component="p">{value}</Typography>
                                            </CardContent>
                                        </CardActionArea>
                                        <CardActions>
                                            <Button size="small" color="primary">Share</Button>
                                            <Button size="small" color="primary">Learn More</Button>
                                        </CardActions>
                                    </Card>
                                ))
                            }
                        </Carousel>
                    </Grid>      
                </Grid>
            ):(
                <center><img alt="" src={banner} style={{maxWidth:'75%'}}/></center>
            )}
        </div>
    );
}
export default React.memo(Jokes);
const useStyles = makeStyles((theme) => ({
    root: {
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'space-around',
      overflow: 'hidden',
      borderColor:'#757575',
      borderWidth:2,
      borderRadius:10,
      backgroundColor: theme.palette.background.paper,
      padding:5,
    },
    gridList: {
      width: 500,
      height: 450,
    },
}));
  